package com.example.practice2;

public interface SecondActivitys {
}
